let partidaEmEdicao = null;

const equipes = {
    "Estados Unidos": 1,
    "México": 2,
    "Canadá": 3,
    "Costa Rica": 4,
    "Jamaica": 5,
    "Panamá": 6,

    "Argentina": 7,
    "Brasil": 8,
    "Uruguai": 9,
    "Colômbia": 10,
    "Equador": 11,
    "Paraguai": 12,
    "Venezuela": 13,

    "França": 14,
    "Inglaterra": 15,
    "Espanha": 16,
    "Alemanha": 17,
    "Portugal": 18,
    "Itália": 19,
    "Países Baixos": 20,
    "Bélgica": 21,
    "Croácia": 22,
    "Dinamarca": 23,
    "Suíça": 24,
    "Áustria": 25,
    "Turquia": 26,
    "Ucrânia": 27,
    "Polônia": 28,
    "Suécia": 29,

    "Marrocos": 30,
    "Senegal": 31,
    "Tunísia": 32,
    "Argélia": 33,
    "Egito": 34,
    "Nigéria": 35,
    "Camarões": 36,
    "Costa do Marfim": 37,
    "Mali": 38,

    "Japão": 39,
    "Coreia do Sul": 40,
    "Irã": 41,
    "Austrália": 42,
    "Arábia Saudita": 43,
    "Catar": 44,
    "Iraque": 45,
    "Uzbequistão": 46,

    "Nova Zelândia": 47,
    "Ilhas Salomão": 48
};

// =====================
// READ
// =====================

async function carregarPartidas() {

    const container =
        document.getElementById('lista-jogos');

    try {

        const resposta =
            await fetch('http://localhost:3000/api/jogos');

        const partidas =
            await resposta.json();

        container.innerHTML = '';

        if (partidas.length === 0) {

            container.innerHTML =
                '<p>Nenhuma partida cadastrada.</p>';

            return;
        }

        partidas.forEach(partida => {

            const card =
                document.createElement('div');

            card.className = 'jogo-card';

            card.innerHTML = `
                <div class="data">
                    ${partida.data}
                </div>

                <div class="times">

                    <div class="time">
                        <img src="${partida.image1}" width="50">
                        <span>${partida.time1}</span>
                    </div>

                    <div class="placar">
                        ${partida.score1} x ${partida.score2}
                    </div>

                    <div class="time">
                        <img src="${partida.image2}" width="50">
                        <span>${partida.time2}</span>
                    </div>

                </div>

                <br>

                <button onclick="editarJogo(${partida.id})">
                    Editar
                </button>

                <button onclick="excluirJogo(${partida.id})">
                    Excluir
                </button>
            `;

            container.appendChild(card);

        });

    } catch (erro) {

        console.error(
            'Erro ao carregar partidas:',
            erro
        );
    }
}

// =====================
// CREATE
// =====================

async function cadastrarJogo() {

    const data =
        document.getElementById('data').value;

    const time1 =
        document.getElementById('time1').value;

    const time2 =
        document.getElementById('time2').value;

    if (!data || !time1 || !time2) {

        alert('Preencha todos os campos.');
        return;
    }

    if (time1 === time2) {

        alert('Selecione equipes diferentes.');
        return;
    }

    const dados = {

        data_partida: data,

        equipe1_id: equipes[time1],

        equipe2_id: equipes[time2],

        gols_equipe1: null,

        gols_equipe2: null,

        status: 'agendada'
    };

    try {

        const resposta =
            await fetch(
                'http://localhost:3000/api/jogos',
                {
                    method: 'POST',
                    headers: {
                        'Content-Type':
                            'application/json'
                    },
                    body:
                        JSON.stringify(dados)
                }
            );

        if (!resposta.ok) {

            throw new Error(
                'Erro ao cadastrar'
            );
        }

        document.getElementById('mensagem').innerText =
            'Partida cadastrada com sucesso!';

        limparFormulario();

        carregarPartidas();

    } catch (erro) {

        console.error(erro);

        alert(
            'Erro ao cadastrar partida.'
        );
    }
}

// =====================
// UPDATE
// =====================

async function editarJogo(id) {

    try {

        const resposta =
            await fetch(
                `http://localhost:3000/api/jogos/${id}`
            );

        const partida =
            await resposta.json();

        partidaEmEdicao = id;

        document.getElementById('data').value =
            partida.data_partida?.substring(0, 10) || '';

        alert(
            'Agora altere os campos e clique em Salvar Edição.'
        );

    } catch (erro) {

        console.error(erro);

        alert(
            'Erro ao carregar partida.'
        );
    }
}

async function salvarEdicao() {

    if (!partidaEmEdicao) {

        alert(
            'Selecione uma partida para editar.'
        );

        return;
    }

    const dados = {

        data_partida:
            document.getElementById('data').value,

        equipe1_id:
            equipes[
                document.getElementById('time1').value
            ],

        equipe2_id:
            equipes[
                document.getElementById('time2').value
            ],

        gols_equipe1: null,

        gols_equipe2: null,

        status: 'agendada'
    };

    try {

        const resposta =
            await fetch(
                `http://localhost:3000/api/jogos/${partidaEmEdicao}`,
                {
                    method: 'PUT',
                    headers: {
                        'Content-Type':
                            'application/json'
                    },
                    body:
                        JSON.stringify(dados)
                }
            );

        if (!resposta.ok) {

            throw new Error(
                'Erro ao atualizar'
            );
        }

        alert(
            'Partida atualizada com sucesso!'
        );

        partidaEmEdicao = null;

        limparFormulario();

        carregarPartidas();

    } catch (erro) {

        console.error(erro);

        alert(
            'Erro ao atualizar partida.'
        );
    }
}

// =====================
// DELETE
// =====================

async function excluirJogo(id) {

    const confirmar =
        confirm(
            'Deseja excluir esta partida?'
        );

    if (!confirmar) return;

    try {

        const resposta =
            await fetch(
                `http://localhost:3000/api/jogos/${id}`,
                {
                    method: 'DELETE'
                }
            );

        if (!resposta.ok) {

            throw new Error(
                'Erro ao excluir'
            );
        }

        carregarPartidas();

    } catch (erro) {

        console.error(erro);

        alert(
            'Erro ao excluir partida.'
        );
    }
}

// =====================
// AUXILIARES
// =====================

function limparFormulario() {

    document.getElementById('data').value = '';

    document.getElementById('time1').selectedIndex = 0;

    document.getElementById('time2').selectedIndex = 0;
}

document.addEventListener(
    'DOMContentLoaded',
    carregarPartidas
);