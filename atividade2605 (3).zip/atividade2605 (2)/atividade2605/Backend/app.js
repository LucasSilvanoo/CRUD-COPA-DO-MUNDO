const express = require('express');
const app = express();
const cors = require('cors');
    
const Partida = require('./src/models/partidas');

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// 🔍 5.1 Read -> GET /api/jogos
app.get('/api/jogos', async (req, res) => {
    try {
        const partidas = await Partida.listarTodas();
        res.json(partidas);
    } catch (err) {
        console.error("Erro ao listar partidas:", err);
        res.status(500).json({ error: "Erro interno ao buscar partidas." });
    }
});

// 🔍 GET /api/jogos/:id
app.get('/api/jogos/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const partida = await Partida.buscarPorId(id);
        if (!partida) {
            return res.status(404).json({ message: "Partida não encontrada." });
        }
        res.json(partida);
    } catch (err) {
        console.error("Erro ao buscar partida:", err);
        res.status(500).json({ error: "Erro interno ao buscar a partida." });
    }
});

// ➕ 5.2 Create -> POST /api/jogos
app.post('/api/jogos', async (req, res) => {
    try {
        const novoId = await Partida.criar(req.body);
        res.status(201).json({ 
            id: novoId, 
            message: "Partida criada com sucesso!" 
        });
    } catch (err) {
        console.error("Erro ao inserir partida:", err);
        res.status(500).json({ error: "Erro interno ao agendar partida." });
    }
});

// ✏️ 5.3 Update -> PUT /api/jogos/:id
app.put('/api/jogos/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const atualizado = await Partida.atualizar(id, req.body);
        if (!atualizado) {
            return res.status(404).json({ message: "Partida não encontrada para atualização." });
        }
        res.json({ message: "Partida atualizada com sucesso!" });
    } catch (err) {
        console.error("Erro ao atualizar partida:", err);
        res.status(500).json({ error: "Erro interno ao atualizar partida." });
    }
});

// ❌ 5.4 Delete -> DELETE /api/jogos/:id
app.delete('/api/jogos/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const deletado = await Partida.deletar(id);
        if (!deletado) {
            return res.status(404).json({ message: "Partida não encontrada." });
        }
        res.json({ message: "Partida removida com sucesso!" });
    } catch (err) {
        console.error("Erro ao deletar partida:", err);
        res.status(500).json({ error: "Erro interno ao remover partida." });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`\n🚀 Servidor backend rodando perfeitamente!`);
    console.log(`👉 Acesse a aplicação em: http://localhost:${PORT}\n`);
});