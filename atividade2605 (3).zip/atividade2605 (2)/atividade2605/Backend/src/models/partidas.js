// 1. Importa a conexão centralizada do seu db.js
const db = require('../data/db');

// 2. Cria um objeto que vai conter todas as operações de banco para as Partidas
const PartidaModel = {
    
    // 🔍 5.1 Read (listar)
    listarTodas: async () => {
        const query = `
            SELECT
                p.id, DATE_FORMAT(p.data_partida, '%d/%m/%Y') AS data, e1.nome AS time1, e1.imagem_url AS image1,
                e1.saiba_mais_url AS saibaMais1, COALESCE(CAST(p.gols_equipe1 AS CHAR), '?') AS score1, e2.nome AS time2,
                e2.imagem_url AS image2, e2.saiba_mais_url AS saibaMais2, COALESCE(CAST(p.gols_equipe2 AS CHAR), '?') AS score2,
                p.status
            FROM partidas p
            JOIN equipes e1 ON e1.id = p.equipe1_id
            JOIN equipes e2 ON e2.id = p.equipe2_id
            ORDER BY p.data_partida, p.id;
        `;
        const [results] = await db.query(query);
        return results;
    },

    // 🔍 Buscar por ID
    buscarPorId: async (id) => {
        const query = 'SELECT * FROM partidas WHERE id = ?';
        const [results] = await db.query(query, [id]);
        return results[0];
    },

    // ➕ 5.2 Create
    criar: async (dados) => {
        const { data_partida, equipe1_id, equipe2_id, gols_equipe1, gols_equipe2, status } = dados;
        const query = `
            INSERT INTO partidas (
                data_partida, equipe1_id, equipe2_id, gols_equipe1, gols_equipe2, status
            ) VALUES (?, ?, ?, ?, ?, ?);
        `;
        const valores = [data_partida, equipe1_id, equipe2_id, gols_equipe1, gols_equipe2, status || 'agendada'];
        const [result] = await db.query(query, valores);
        return result.insertId;
    },

    // ✏️ 5.3 Update
    atualizar: async (id, dados) => {
        const { data_partida, equipe1_id, equipe2_id, gols_equipe1, gols_equipe2, status } = dados;
        const query = `
            UPDATE partidas
            SET data_partida = ?, equipe1_id = ?, equipe2_id = ?, gols_equipe1 = ?, gols_equipe2 = ?, status = ? 
            WHERE id = ?;
        `;
        const valores = [data_partida, equipe1_id, equipe2_id, gols_equipe1, gols_equipe2, status, id];
        const [result] = await db.query(query, valores);
        return result.affectedRows > 0;
    },

    // ❌ 5.4 Delete
    deletar: async (id) => {
        const query = 'DELETE FROM partidas WHERE id = ?;';
        const [result] = await db.query(query, [id]);
        return result.affectedRows > 0;
    }
};

// 3. Exporta o modelo para ser usado nas rotas
module.exports = PartidaModel;