const pool = require('../config/mysql');

module.exports = pool;